# 04. Reglas de cumplimiento

## Principio

La app debe separar tres capas:

1. Plan: lo que se debía hacer.
2. Promesa: lo que Sergio dijo que haría.
3. Evidencia: lo que efectivamente hizo.

Solo la evidencia afecta cumplimiento.

## Colores del heatmap

- Verde: cumplió 100% o más del objetivo del día.
- Amarillo: hizo entrenamiento, pero bajo el kilometraje o contenido del plan.
- Rojo: día vencido con sesión planificada y sin evidencia suficiente.
- Gris / azul oscuro: día sin sesión planificada o futuro.
- Alerta lesión: usar borde o ícono si hay dolor/periostitis, incluso si el día fue verde o amarillo.

## Fórmula diaria

```ts
if (!plannedSession) return "neutral";
if (date > today) return "future";
if (actualKm === 0) return "red";
if (actualKm >= plannedKm) return "green";
return "yellow";
```

Con lesión:

```ts
if (painReported && status !== "red") addFlag("injury_alert");
```

## Fórmula semanal

- `km_real_semana = suma sesiones canónicas de la semana`
- `km_objetivo_semana = planned_week.target_km`
- `cumplimiento_km_pct = km_real_semana / km_objetivo_semana`
- `sesiones_planificadas = count(planned_sessions donde type != rest)`
- `sesiones_realizadas = count(días con evidencia válida)`
- `cumplimiento_sesiones_pct = sesiones_realizadas / sesiones_planificadas`

## Visualización pedida

El heatmap debe tener días en columnas y semanas en filas.

La última columna no debe juntar objetivo y real. Deben ser dos cards separadas:

- Card 1: objetivo semanal.
- Card 2: real semanal.

Redondear máximo a 1 decimal.

## Reglas específicas actuales

### Semana 22-28 junio 2026

Plan vigente:

- Martes: 3,5 km.
- Miércoles: 3 km.
- Jueves: 3,5 km.
- Viernes: 5 km.
- Domingo: 10 km.
- Objetivo semanal: 25 km.

Evidencia cargada:

- 23-06-2026: 3,03 km indoor, 22:31, 7:26/km.
- 25-06-2026: 3,03 km indoor, 21:43, 7:10/km.
- 26-06-2026: 4,37 km outdoor, 32:15, 7:23/km, FC promedio 132, FC máx 171.

Lectura:

- Viernes queda amarillo/parcial porque entrenó, pero no completó los 5 km.
- Gimnasio no se considera cumplido si no hay evidencia objetiva; “la fuerza no la mido, solo la siento” no basta.
- Dolor/periostitis queda como alerta de control, no como excusa automática.

## Veredicto semanal recomendado

Clasificación:

- Cumplida: >=90% km + >=80% sesiones + sin dolor acumulado.
- Parcial: 60%-89% km o sesiones incompletas.
- Incumplida: <60% km o falta de evidencia.
- Riesgo: cualquier nivel de cumplimiento con dolor persistente, periostitis, fatiga fuerte o progresión imprudente.
