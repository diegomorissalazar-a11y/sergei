# 02. Modelo de datos sugerido

## Entidades principales

### athlete

```ts
{
  id: string;
  name: string;
  height_cm?: number;
  current_weight_kg?: number;
  notes?: string;
}
```

### weight_logs

```ts
{
  id: string;
  athlete_id: string;
  date: string; // YYYY-MM-DD
  weight_kg: number;
  source: "manual" | "captura" | "historico";
  is_real: boolean;
  notes?: string;
}
```

### weight_projection

```ts
{
  id: string;
  athlete_id: string;
  start_date: string;
  start_weight_kg: number;
  target_date: string;
  target_weight_kg: number;
  weekly_delta_kg: number;
  notes?: string;
}
```

### training_sessions

```ts
{
  id: string;
  athlete_id: string;
  date: string;
  time?: string;
  type: "run_outdoor" | "run_indoor" | "bike" | "walk" | "elliptical" | "gym" | "other";
  title?: string;
  distance_km?: number;
  duration_sec?: number;
  pace_sec_per_km?: number;
  calories?: number;
  avg_hr?: number;
  max_hr?: number;
  cadence_spm?: number;
  stride_cm?: number;
  steps?: number;
  elevation_gain_m?: number;
  source: "huawei" | "strava" | "official" | "manual" | "capture";
  evidence: "screenshot" | "official_chip" | "message" | "manual";
  notes?: string;
  duplicate_group?: string;
  canonical?: boolean;
}
```

### planned_weeks

```ts
{
  id: string;
  athlete_id: string;
  week_start: string;
  week_end: string;
  target_km: number;
  status: "past" | "current" | "future";
  notes?: string;
}
```

### planned_sessions

```ts
{
  id: string;
  planned_week_id: string;
  day: "lunes" | "martes" | "miércoles" | "jueves" | "viernes" | "sábado" | "domingo";
  date?: string;
  type: "run" | "gym" | "bike" | "rest";
  target_km?: number;
  target_pace_range?: string;
  target_detail?: string;
}
```

### compliance_daily

```ts
{
  id: string;
  date: string;
  planned_session_id?: string;
  actual_session_ids: string[];
  planned_km?: number;
  actual_km?: number;
  status: "green" | "yellow" | "red" | "neutral" | "future" | "injury_alert";
  compliance_pct?: number;
  notes?: string;
}
```

### race_events

```ts
{
  id: string;
  athlete_id: string;
  event_name: string;
  date?: string;
  distance_km?: number;
  official_time_sec?: number;
  gun_time_sec?: number;
  official_pace_sec_per_km?: number;
  source: "official_chip" | "screenshot" | "manual";
  medal: boolean;
  notes?: string;
}
```

### discourse_logs

```ts
{
  id: string;
  athlete_id: string;
  date?: string;
  speaker: "sergio" | "coach";
  quote: string;
  category: "reinicio" | "dolor" | "lesion" | "gym" | "peso" | "running" | "autogestion" | "humor" | "riesgo" | "motivacion";
  interpretation?: string;
  evidence: "message" | "capture" | "manual";
}
```

### injury_alerts

```ts
{
  id: string;
  athlete_id: string;
  date: string;
  area: string;
  issue: string;
  severity: "low" | "medium" | "high" | "unknown";
  status: "open" | "watch" | "resolved";
  rule: string;
  notes?: string;
}
```

### body_photos

```ts
{
  id: string;
  athlete_id: string;
  date?: string;
  image_ref?: string;
  context?: string;
  notes?: string;
}
```

## Funciones de cálculo recomendadas

- `paceToSeconds("7:23") => 443`
- `secondsToPace(443) => "7:23"`
- `sumWeeklyKm(sessions, weekStart, weekEnd)`
- `classifyDailyCompliance(plannedKm, actualKm, dueDate, painFlag)`
- `classifyWeeklyCompliance(targetKm, actualKm, plannedSessions, actualSessions)`
- `dedupeSessionsByDateDistanceDuration()`

## Dedupe

Si hay dos registros duplicados de una misma sesión:

1. Preferir dato oficial de chip sobre reloj.
2. Preferir registro con más campos completos.
3. Si son capturas de la misma sesión, conservar solo un `canonical: true` y dejar las otras como evidencia secundaria.
4. No sumar dos veces.
