# 05. Prompt para GitHub / Copilot / otro chat

Estoy trabajando en una app ya montada para monitorear el seguimiento deportivo de Sergio Espinoza. Necesito modificarla bajo este esquema y dejarla lista para cargar a GitHub.

## Objetivo de la app

Construir una app de monitoreo longitudinal para Sergio Espinoza, centrada en:

- Running.
- Gimnasio.
- Peso real y proyección.
- Composición corporal por fotos.
- Plan semanal vs evidencia real.
- Heatmap de cumplimiento.
- Medallero / carreras oficiales.
- Lesiones y dolor, especialmente periostitis tibial.
- Análisis de discurso deportivo.

La regla central es: no se valida por intención ni por épica. Se valida por evidencia: sesión, km, ritmo, FC si hay, gym registrado y peso semanal.

## Archivos de entrada

Usar como fuente principal el archivo `03_seed_sergio_monitor.json`.

Debe existir un importador JSON que cargue:

- athlete
- weight_logs
- weight_projection
- training_sessions
- monthly_summaries
- planned_weeks
- planned_sessions
- compliance_daily
- race_events
- discourse_logs
- injury_alerts
- coach_messages

## Requerimientos funcionales

### 1. Dashboard

Crear o ajustar dashboard con estas secciones:

1. Resumen ejecutivo.
2. Peso real vs proyección.
3. Serie histórica de running.
4. Volumen mensual en barras.
5. Heatmap semanal.
6. Cards separadas de objetivo semanal y real semanal.
7. Plan vigente.
8. Medallero.
9. Discurso deportivo.
10. Alertas de lesión.
11. Diagnóstico.

### 2. Peso real vs proyección

- Mostrar peso real histórico como línea sólida.
- Mostrar una línea vertical de “hoy”.
- Mostrar proyección futura como línea punteada.
- No mezclar dato real y proyectado.
- Peso base actual: 116,0 kg.
- Proyección inicial: 109,3 kg al 31-12-2026, a -0,25 kg/semana.

### 3. Serie histórica running

- Barras: kilómetros por sesión.
- Línea: ritmo promedio.
- Tooltip: fecha, distancia, duración, ritmo, calorías, FC promedio, FC máxima si existe.
- Dedupe obligatorio: no sumar dos veces registros duplicados.
- Si hay carrera oficial, usar lectura de chip como canónica.

### 4. Volumen mensual

- Usar gráfico de barras por mes.
- Preferir barras sobre línea.
- Mostrar running_km cargado desde monthly_summaries y/o calculado desde sesiones.

### 5. Heatmap

Colores:

- Verde: cumplió 100% o más.
- Amarillo: entrenó, pero bajo objetivo.
- Rojo: vencido sin evidencia.
- Gris/azul oscuro: futuro o sin sesión.
- Borde/ícono de alerta si hubo dolor o periostitis.

Importante: redondear todo a máximo 1 decimal.

La última columna no debe juntar real y objetivo. Separar en dos cards:

- Objetivo semanal.
- Real semanal.

### 6. Plan vigente

Usar plan actual enviado el sábado, no el plan antiguo.

Semana actual 22-28 junio 2026:

- Martes 3,5 km.
- Miércoles 3 km.
- Jueves 3,5 km.
- Viernes 5 km.
- Domingo 10 km.
- Total objetivo: 25 km.

Evidencia cargada:

- 23-06-2026: 3,03 km indoor, 22:31, 7:26/km.
- 25-06-2026: 3,03 km indoor, 21:43, 7:10/km.
- 26-06-2026: 4,37 km outdoor, 32:15, 7:23/km, 462 kcal, FC promedio 132, FC máx 171, cadencia 140, zancada 97 cm, 4.528 pasos.

Viernes debe quedar amarillo/parcial porque entrenó, pero no completó los 5 km.

### 7. Medallero

Mostrar eventos con emoji de medalla.

- 🏅 Maratón de Santiago 21K: 21,097 km, 02:28:06, 7:01/km, chip oficial.
- 🏅 Corrida Mes del Mar / Viña del Mar 21K: 02:22:27 chip, 02:25:00 gun, 6:54/km, mejor 21K registrado.
- 🏅 Gana Santiago: pendiente de tiempo.

Usar el chip oficial como dato principal.

### 8. Discurso deportivo

Crear tabla o cards con fecha, frase, categoría y lectura.

Frases importantes:

- “mi abuela me dijo oh que estás gordo, come menos”.
- “apareció un dolor al correr pero no duró 24 horas”.
- “periostitis tibial conocida”.
- “la fuerza no la mido, solo la siento”.
- “no duraron nada mis intervalos xd, no alcance los 600 creo que fueron 500”.
- “duro como 2 minutos corriendo a 4:30”.
- “creo que no tengo que correr a 4:30... como a las 5:30... mi yo no aspiro un 4:30”.
- “buen día rodillas”.

### 9. Alertas

Crear alerta activa para periostitis tibial:

- Estado: watch.
- Regla: cerrar semana con km, gym y cero dolor acumulado.
- Si dolor dura más de 24 horas o aumenta, marcar riesgo.

### 10. Gimnasio

No marcar gimnasio como cumplido solo con frases. La frase “la fuerza no la mido, solo la siento” debe quedar como evidencia subjetiva, no como sesión validada.

## Requerimientos técnicos

- La app debe aceptar carga por JSON.
- Debe permitir carga manual de sesión.
- Debe permitir editar plan semanal.
- Debe calcular cumplimiento automáticamente.
- Debe soportar exportar HTML o reporte semanal.
- Debe deduplicar sesiones.
- Debe diferenciar fuente: Huawei, Strava, oficial, manual, captura.

## Resultado esperado

Entregar código listo para GitHub con:

- Componentes actualizados.
- Importador JSON.
- Seed data.
- Dashboard responsive.
- README con instrucciones.
- Sin inventar datos faltantes.
- Si falta información, marcar como pendiente.
