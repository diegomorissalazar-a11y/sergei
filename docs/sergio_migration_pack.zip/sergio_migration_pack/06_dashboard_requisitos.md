# 06. Requisitos del dashboard

## Secciones obligatorias

1. Resumen ejecutivo.
2. Peso real vs proyección.
3. Serie histórica running: barras por km de sesión + línea de ritmo promedio.
4. Volumen mensual: gráfico de barras.
5. Heatmap semanal de cumplimiento.
6. Cards separadas: objetivo semanal y real semanal.
7. Plan vigente.
8. Medallero / eventos oficiales.
9. Discurso deportivo.
10. Alertas de lesión / dolor.
11. Diagnóstico actualizado.
12. Fotos de composición corporal, si se habilita galería.

## Peso real vs proyección

- Mantener serie real histórica.
- Línea real en color propio hasta hoy.
- Línea vertical “hoy”.
- Proyección punteada desde hoy hacia objetivo.
- No mezclar dato real con proyectado.

## Running

- Serie histórica por sesión.
- Barras: km.
- Línea: ritmo promedio.
- Tooltip con fecha, km, ritmo, duración, FC si existe.
- Dedupe obligatorio.

## Volumen mensual

Preferir gráfico de barras por mes. El usuario indicó que el de barras era más claro que el gráfico de línea.

## Heatmap

- Mantener colores de cumplimiento.
- Mostrar objetivo diario y real diario.
- Máximo 1 decimal.
- Separar objetivo semanal y real semanal en dos cards.

## Medallero

Cada evento debe mostrarse como carrera/medalla:

- 🏅 Maratón de Santiago 21K: chip 02:28:06, ritmo 7:01/km.
- 🏅 Corrida Mes del Mar / Viña del Mar 21K: chip 02:22:27, gun 02:25:00, ritmo 6:54/km.
- 🏅 Gana Santiago: pendiente de tiempo.

Usar solo chip oficial como tiempo principal. El reloj o llegada no reemplazan el dato oficial.

## Discurso deportivo

Mostrar tabla con:

- Fecha.
- Frase.
- Categoría.
- Lectura.
- Riesgo / acción.

Categorías sugeridas:

- Reinicio.
- Running.
- Gym.
- Peso.
- Lesión.
- Alcohol / comida si aparece.
- Autogestión.
- Humor.
- Riesgo.
- Motivación.

## Diagnóstico

Debe tener tono firme, humano y no ingenuo. No condescendiente. Priorizar evidencia objetiva.

Frase de control sugerida:

> Che, el progreso no se anuncia: se registra. Una semana cumplida vale más que diez “ahora sí”.
