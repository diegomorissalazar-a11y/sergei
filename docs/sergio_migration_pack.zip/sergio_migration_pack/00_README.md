# Sergio Monitor — paquete de migración

Objetivo: llevar el seguimiento de Sergio Espinoza desde dashboard HTML / análisis manual hacia una app de monitoreo con datos estructurados, carga por JSON, control de plan vs evidencia y actualización en GitHub.

Este paquete consolida:

- Memoria operativa del proyecto.
- Reglas de cumplimiento y control.
- Modelo de datos sugerido.
- Seed JSON inicial con sesiones, plan, eventos, peso, discurso y alertas.
- Requerimientos para modificar una app ya montada.
- Prompt listo para usar en otro chat o con Copilot.

Principio rector: no se valida por intención ni por épica; se valida por evidencia: sesión, kilómetros, ritmo, frecuencia cardíaca si existe, gimnasio con prueba objetiva, peso semanal y evolución de dolor.

## Archivos

1. `01_memoria_proyecto.md`: contexto histórico y reglas acordadas.
2. `02_modelo_datos.md`: entidades, campos y relaciones sugeridas.
3. `03_seed_sergio_monitor.json`: datos iniciales estructurados para importar.
4. `04_reglas_cumplimiento.md`: reglas de heatmap, KPI y lectura semanal.
5. `05_prompt_github_copilot.md`: prompt para pedir implementación sobre app existente.
6. `06_dashboard_requisitos.md`: requerimientos visuales y funcionales del dashboard.
7. `07_changelog_datos.md`: registro de datos nuevos y correcciones relevantes.

## Restricciones importantes

- Usar solo evidencia válida: mensajes enviados por Sergio e imágenes/registros de Sergio.
- No usar mensajes de terceros para evaluar a Sergio.
- No usar audios no transcritos; si el audio aparece con transcripción parcial, marcarlo como transcripción no validada.
- Distinguir siempre plan, promesa y evidencia real.
- Distinguir peso real de peso proyectado.
- Distinguir registro oficial de chip vs registro de reloj.
