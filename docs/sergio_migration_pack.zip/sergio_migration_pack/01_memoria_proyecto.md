# 01. Memoria del proyecto — Sergio Espinoza

## Propósito

Construir una app de monitoreo longitudinal para Sergio Espinoza, centrada en running, gimnasio, peso/composición corporal, lesiones, cumplimiento de plan y análisis de discurso deportivo.

El usuario quiere controlar adherencia real y coherencia conducta-discurso. Sergio suele decir que ahora sí retomará, pero el seguimiento debe priorizar evidencia objetiva por sobre promesas.

## Perfil base

- Nombre: Sergio Andrés Espinoza Sepúlveda.
- Altura informada: 184 cm.
- Peso base actual para dashboard: 116,0 kg.
- Objetivo de control: continuidad, pérdida de peso, composición corporal y running sin lesión acumulada.
- Riesgo principal: peso alto + progresiones bruscas + periostitis tibial / dolor de rodillas.

## Principio de evaluación

> No se valida por intención. Se valida por evidencia: sesión, km, ritmo, FC si hay, gym y peso semanal.

## Evidencia válida

Usar solo:

- Capturas de entrenamientos de Sergio.
- Mensajes enviados por Sergio.
- Fotos de Sergio para seguimiento de composición corporal.
- Datos oficiales de carrera cuando existan.

No usar:

- Mensajes de terceros para evaluar a Sergio.
- Audios no transcritos o transcripciones incompletas como dato fuerte.
- Promesas sin evidencia de ejecución.

## Estado del dashboard previo

El HTML venía evolucionando con:

- Peso real vs proyección.
- Serie histórica de running.
- Volumen mensual en barras.
- Heatmap semanal de cumplimiento.
- Separación de objetivo semanal y real semanal en dos cards.
- Medallero / eventos oficiales.
- Análisis de discurso deportivo.
- Diagnóstico actualizado.

## Correcciones acordadas

### Peso

- Recuperar serie real histórica de peso desde versiones anteriores.
- Mantener peso real separado de proyección.
- En gráfico: línea real en color distinto hasta hoy; línea vertical de hoy; desde hoy, proyección punteada hacia objetivo.
- Proyección previa: desde 116,0 kg hacia aprox. 109,3 kg al 31-12-2026 usando baja estimada de 250 g/semana.

### Eventos / medallero

- Dejar solo lectura oficial del chip cuando exista.
- Maratón de Santiago 21K: tiempo oficial chip 02:28:06, ritmo 7:01/km.
- Corrida Mes del Mar / Viña del Mar: 21K, chip 02:22:27, gun 02:25:00, ritmo 6:54/km, mejor 21K registrado.
- Gana Santiago: sin tiempo cargado todavía.
- Agregar emoji de medalla al dato.

### Heatmap

- Mantener colores:
  - Verde: cumplió 100% o más.
  - Amarillo: entrenó, pero no cumplió kilometraje del plan.
  - Rojo: día vencido sin evidencia o incumplido.
  - Gris/azul oscuro: día futuro o sin sesión planificada.
- Máximo 1 decimal.
- Separar la última columna en dos cards: objetivo semanal y real semanal.

### Plan actual

Usar el plan enviado el sábado como plan vigente, no el plan antiguo. El plan antiguo solo sirve para contrastar si lo logró o no.

Plan vigente desde captura:

| Mes | Semana | Lunes | Martes | Miércoles | Jueves | Viernes | Sábado | Domingo | Objetivo km | Nota |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| Junio | 15-21 |  |  |  | 3,1 |  | 4,07 | 7 | 14,17 | base real |
| Junio | 22-28 |  | 3,5 | 3 | 3,5 | 5 |  | 10 | 25 | plan vigente |
| Junio/Julio | 29-05 |  | 3,5 | 3 | 3,5 | 6 |  | 10 | 26 | plan |
| Julio | 6-12 |  | 3,5 |  | 3,5 | 7 |  | 12 | 26 | plan |
| Julio | 13-19 |  | 3,5 |  | 3,5 | 7 |  | 14 | 28 | plan |
| Julio | 20-26 |  | 3,5 |  | 3,5 | 8 |  | 16 | 31 | plan |
| Julio | 27-02 |  | 3,5 |  |  | 4 | 3,5 | 10 | 21 | descarga |
| Agosto | 3-9 | 3 | 3,5 |  | 5 |  | 3,5 | 10 | 22 | plan |
| Agosto | 10-16 | 3 | 3,5 |  | 6 |  | 3,5 | 12 | 25 | plan |
| Agosto | 17-23 | 3 | 3,5 |  | 7 |  | 3,5 | 7 | 21 | taper |
| Agosto | 24-30 |  | 3,5 | 3 |  |  | 3,5 | 10 | 20 | taper / corrida |

## Frases y discurso relevante

### Frase de la abuela

- Fecha: 23-11-2025.
- Frase: “mi abuela me dijo oh que estás gordo, come menos”.
- Lectura: el peso aparece como tema social/familiar, no solo deportivo.

### Frases de control / seguimiento

- “Che, el progreso no se anuncia: se registra. Una semana cumplida vale más que diez ‘ahora sí’.”
- “Bien que estés avisando el dolor y no escondiéndolo. Pero esta semana no se gana por prometer ni por épica: se gana con evidencia. Si hay periostitis, el objetivo no es demostrar valentía; es cerrar la semana con kilómetros, gym y cero dolor acumulado.”

### Frases recientes de Sergio

- “viernes en la noche libero todos los datos”.
- “apareció un dolor al correr pero no duró 24 horas”.
- “domingo se corre 7k muy temprano y muy suave”.
- “periostitis tibial conocida”.
- “vamos a salir adelante”.
- “voy entero bien”.
- “hoy no comí tonteras”.
- “la extrema pobreza es la mejor consejera”.
- “hoy me toca gym”.
- “la fuerza no la mido, solo la siento”.
- “no duraron nada mis intervalos xd, no alcancé los 600, creo que fueron 500”.
- “duro como 2 minutos corriendo a 4:30”.
- “creo que no tengo que correr a 4:30... como a las 5:30... mi yo no aspiro un 4:30”.
- “buen día rodillas” / chiste de rodillas.

## Lectura del discurso deportivo

Patrones detectados:

- Deseo / reinicio: “ahora sí”, “vamos a salir adelante”.
- Épica / dramatización: tendencia a convertir el plan en relato emocional.
- Autogestión parcial: avisa dolor, reconoce que 4:30/km no corresponde, propone ajustar.
- Riesgo: prometer volumen o velocidad sin evidencia suficiente.
- Gimnasio: aún débil como evidencia, porque “la fuerza no la mido, solo la siento”.

## Diagnóstico actualizado

Sergio no es principiante puro: hay base real y capacidad demostrada con fondos de 10K, 13K, 15K y 21K. El problema principal no es capacidad, sino continuidad, peso corporal, progresiones bruscas y evidencia incompleta de gimnasio.

La semana no debe ganarse por prometer ni por épica. Debe ganarse con sesiones verificables, kilómetros cumplidos, dolor controlado y gimnasio registrado.
