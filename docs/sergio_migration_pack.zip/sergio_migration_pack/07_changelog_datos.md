# 07. Changelog de datos y correcciones

## Correcciones importantes

### 21K

Se corrigió que no debe haber doble dato para 21K cuando uno es registro oficial y otro reloj/llegada. Para el dashboard y app usar:

- Maratón de Santiago 21K: chip oficial 02:28:06, ritmo 7:01/km.
- Registro de llegada/reloj no reemplaza chip.

### Corrida Mes del Mar

Agregar al medallero:

- Corrida Mes del Mar / Viña del Mar.
- 21K.
- Chip 02:22:27.
- Gun 02:25:00.
- Ritmo 6:54/km.
- Nota: mejor 21K registrado disponible.
- Año/fecha exacta pendiente de confirmar entre 2024/2026 según nota previa.

### Gana Santiago

Agregar al medallero como pendiente:

- Gana Santiago.
- Tiempo no cargado.

### Peso

Recuperar serie real de versiones anteriores. Mantener:

- 127 kg reportado históricamente el 22-07-2024.
- 116 kg actual como base.
- Proyección a 109,3 kg al 31-12-2026.

### Heatmap

Se corrigió que el heatmap estaba bien en colores. Solo se pidió separar la última columna en dos cards:

- Objetivo semanal.
- Real semanal.

### Gráficos

Hubo problema de visualización de gráficos en HTML. En la app evitar dependencia frágil de canvas si se exporta como HTML estático. Recomendación:

- Usar componentes robustos tipo Recharts/Chart.js en app.
- Para export HTML, renderizar SVG o asegurar inicialización de scripts.
- Mantener fallback de tabla cuando el gráfico no cargue.

## Nuevos datos recientes

### Semana 22-28 junio 2026

Plan vigente:

- Martes 3,5 km.
- Miércoles 3 km.
- Jueves 3,5 km.
- Viernes 5 km.
- Domingo 10 km.

Evidencia:

- 23-06-2026: 3,03 km indoor, 22:31, 7:26/km.
- 25-06-2026: 3,03 km indoor, 21:43, 7:10/km.
- 26-06-2026: 4,37 km outdoor, 32:15, 7:23/km, 462 kcal, FC promedio 132, FC max 171, cadencia 140, zancada 97 cm, 4.528 pasos.

Lectura:

- Viernes amarillo/parcial: entrenó, pero no llegó a 5 km.
- Intervalos planificados de 600 m no se completaron; Sergio cree que fueron 500 m.
- Reconoce que 4:30/km es demasiado rápido para sostener.
- Hay periostitis tibial conocida / dolor informado.
- Gimnasio no validado con evidencia objetiva.

## Frases nuevas

- “la fuerza no la mido, solo la siento”.
- “Chequeé ayer cuando corrí lento igual corría como a 7:30 ocho así...”
- “no duraron nada mis intervalos xd no alcance los 600 creo que fueron 500”.
- “duro como 2 minutos corriendo a 4:30”.
- “creo que no tengo que correr a 4:30... como a las 5:30”.
- “buen día rodillas”.

## Veredicto con última información

Hay señales positivas de autogestión: avisa dolor, reconoce ritmos imprudentes y entrega evidencia. Pero el cumplimiento sigue parcial porque la semana se evalúa por plan real, no por intención. El foco debe ser cerrar semana con kilómetros controlados, gimnasio medible y cero dolor acumulado.
